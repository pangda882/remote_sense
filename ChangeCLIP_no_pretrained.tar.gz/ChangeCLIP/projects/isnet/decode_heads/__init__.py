from .isnet_head import ISNetHead

__all__ = ['ISNetHead']
