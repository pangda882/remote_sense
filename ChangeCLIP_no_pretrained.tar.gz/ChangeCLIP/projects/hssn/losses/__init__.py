# Copyright (c) OpenMMLab. All rights reserved.
from .hiera_triplet_loss_cityscape import HieraTripletLossCityscape

__all__ = ['HieraTripletLossCityscape']
