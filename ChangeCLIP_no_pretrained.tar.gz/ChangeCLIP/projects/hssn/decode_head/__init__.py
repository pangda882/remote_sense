# Copyright (c) OpenMMLab. All rights reserved.
from .sep_aspp_contrast_head import DepthwiseSeparableASPPContrastHead

__all__ = ['DepthwiseSeparableASPPContrastHead']
